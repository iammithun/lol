# -*- coding: utf-8 -*-
"""
Created on Sun Feb 18 16:44:53 2024

@author: iamrs
"""

import turtle

def draw_circle(speed):

    t = turtle.Turtle()
    
   
    t.speed(speed)


    t.circle(100000000000000000000000000)

    turtle.done()


draw_circle(speed=1000000000000)
