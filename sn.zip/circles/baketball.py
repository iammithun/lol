import turtle

def draw_circle(color, radius):
    turtle.color(color)
    turtle.begin_fill()
    turtle.circle(radius)
    turtle.end_fill()

def draw_basketball():
    turtle.speed(0)
    turtle.bgcolor("orange")
    turtle.penup()
    turtle.goto(0, -200)
    turtle.pendown()

    draw_circle("darkorange", 200)
    draw_circle("white", 180)
    draw_circle("darkorange", 170)
    draw_circle("black", 160)

    turtle.hideturtle()
    turtle.done()

if __name__ == "__main__":
    draw_basketball()
