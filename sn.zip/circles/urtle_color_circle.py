
import turtle as t
t.color("blue")
t.circle(1000)
t.circle (999)
t.circle(199)
